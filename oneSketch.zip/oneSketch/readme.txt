The OneSketch dataset contains 2181 sketches, differentiating between 50 images.

the data structure is as follows:

image folder:
    contains the 50 images labeled 0-49

Data folder:
    contains .a files in the JSON format, each file containing the following keys:

    Drawing: contaings x,y pairs of the sketch's points. The coordinates were originally drawn on a 500x500 canvas and have a maximum value of 500.

    images: an array of 4 indicies. indexes 1-3 denote the number of the images (range of 0-49) the user was shown when drawing the sketch, while
    the first index (index 0) is in the 0-2 range, denoting which of the three images is correct.

    auxilary keys:
    touchscreen: denotes if the user used a touch screen or not in the sketch drawing process
    wrong, right, total: given the drawn sketch, how many users were able to select the correct image
    timestamp: the date the sketch was drawn on
    exampleScore: prior to drawing the sketches, and after reading our instructions, users are given questions to verify their knowledge of the task
    denotes how many questions the user got right
    imageSubmissionOrder: When the user draws several sketches in a single session, the number n denotes the sketch is the n-th one submitted

sketches folder:
    the sketches rendered from the data entries in the data folder, by connecting the drawing's points using a straight line of width 5 on a 500x500
    and then resizing it to 256x256. The file names match the .a file in the data folder used to generate the sketch.
    
        
